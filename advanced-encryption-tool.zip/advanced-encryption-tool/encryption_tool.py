#!/usr/bin/env python3
import getpass, os, sys
from dataclasses import dataclass
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.scrypt import Scrypt

MAGIC = b"AETv1\x00\x00\x00"
VERSION = 1
SALT_SIZE = 16
NONCE_SIZE = 12
KEY_LEN = 32

@dataclass
class Header:
    magic: bytes
    version: int
    salt: bytes
    nonce: bytes

def derive_key(password: str, salt: bytes) -> bytes:
    kdf = Scrypt(salt=salt, length=KEY_LEN, n=2**14, r=8, p=1)
    return kdf.derive(password.encode())

def write_header(f, salt, nonce):
    f.write(MAGIC)
    f.write(bytes([VERSION]))
    f.write(salt)
    f.write(nonce)

def read_header(f) -> Header:
    magic = f.read(len(MAGIC))
    if magic != MAGIC:
        raise ValueError("Not an AET file")
    version = f.read(1)[0]
    if version != VERSION:
        raise ValueError("Unsupported version")
    salt = f.read(SALT_SIZE)
    nonce = f.read(NONCE_SIZE)
    return Header(magic, version, salt, nonce)

def encrypt_file(input_path, output_path, password):
    salt = os.urandom(SALT_SIZE)
    nonce = os.urandom(NONCE_SIZE)
    key = derive_key(password, salt)
    aesgcm = AESGCM(key)
    with open(input_path, 'rb') as f:
        plaintext = f.read()
    ciphertext = aesgcm.encrypt(nonce, plaintext, None)
    with open(output_path, 'wb') as f:
        write_header(f, salt, nonce)
        f.write(ciphertext)

def decrypt_file(input_path, output_path, password):
    with open(input_path, 'rb') as f:
        header = read_header(f)
        key = derive_key(password, header.salt)
        aesgcm = AESGCM(key)
        ciphertext = f.read()
    plaintext = aesgcm.decrypt(header.nonce, ciphertext, None)
    with open(output_path, 'wb') as f:
        f.write(plaintext)

def main():
    if len(sys.argv) < 3:
        print("Usage: python3 encryption_tool.py <encrypt|decrypt> <input> [output]")
        sys.exit(1)
    cmd = sys.argv[1].lower()
    in_path = sys.argv[2]
    out_path = sys.argv[3] if len(sys.argv) > 3 else (
        in_path + ".aet" if cmd == "encrypt" else in_path.replace(".aet", ""))
    password = getpass.getpass("Enter password: ")
    if cmd == "encrypt":
        confirm = getpass.getpass("Confirm password: ")
        if password != confirm:
            print("Passwords do not match")
            sys.exit(1)
        encrypt_file(in_path, out_path, password)
        print(f"[+] Encrypted -> {out_path}")
    elif cmd == "decrypt":
        try:
            decrypt_file(in_path, out_path, password)
            print(f"[+] Decrypted -> {out_path}")
        except Exception:
            print("[-] Wrong password or corrupted file")
    else:
        print("Unknown command")

if __name__ == "__main__":
    main()
