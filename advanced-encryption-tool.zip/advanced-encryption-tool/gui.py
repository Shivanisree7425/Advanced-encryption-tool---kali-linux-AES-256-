#!/usr/bin/env python3
import tkinter as tk
from tkinter import filedialog, messagebox
from encryption_tool import encrypt_file, decrypt_file
import getpass, os

root = tk.Tk()
root.title("Advanced Encryption Tool")
root.geometry("400x250")

file_path = ""

def select_file():
    global file_path
    file_path = filedialog.askopenfilename()
    if file_path:
        file_label.config(text=f"Selected: {os.path.basename(file_path)}")

def encrypt_action():
    if not file_path:
        messagebox.showerror("Error", "No file selected")
        return
    password = getpass.getpass("Enter password: ")
    confirm = getpass.getpass("Confirm password: ")
    if password != confirm:
        messagebox.showerror("Error", "Passwords do not match")
        return
    out_path = file_path + ".aet"
    encrypt_file(file_path, out_path, password)
    messagebox.showinfo("Success", f"Encrypted -> {out_path}")

def decrypt_action():
    if not file_path:
        messagebox.showerror("Error", "No file selected")
        return
    password = getpass.getpass("Enter password: ")
    out_path = file_path.replace(".aet", "")
    try:
        decrypt_file(file_path, out_path, password)
        messagebox.showinfo("Success", f"Decrypted -> {out_path}")
    except Exception:
        messagebox.showerror("Error", "Wrong password or corrupted file")

tk.Button(root, text="Select File", command=select_file).pack(pady=5)
file_label = tk.Label(root, text="No file selected")
file_label.pack(pady=5)
tk.Button(root, text="Encrypt", command=encrypt_action).pack(pady=5)
tk.Button(root, text="Decrypt", command=decrypt_action).pack(pady=5)

root.mainloop()
